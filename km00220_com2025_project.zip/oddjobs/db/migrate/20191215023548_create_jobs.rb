class CreateJobs < ActiveRecord::Migration[5.2]
  def change
    create_table :jobs do |t|
      t.belongs_to :company, foreign_key: true, null: false
      t.string :title, null: false
      t.integer :salary
      t.string :postcode
      t.text :description, null: false

      t.timestamps, null: false
    end
  end
end

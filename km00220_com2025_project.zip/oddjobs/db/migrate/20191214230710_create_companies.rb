class CreateCompanies < ActiveRecord::Migration[5.2]
  def change
    create_table :companies do |t|
      t.string :title, null: false
      t.string :contact
      t.string :email

      t.timestamps
    end
  end
end

class CreateApplications < ActiveRecord::Migration[5.2]
  def change
    create_table :applications do |t|
      t.belongs_to :job, foreign_key: true, null: false
      t.string :name, null: false
      t.string :number, null: false
      t.string :email, null: false
      t.string :application, null: false

      t.timestamps
    end
  end
end

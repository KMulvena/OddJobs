# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)

google = Company.where(title: 'Google').first
google.delete if google

microsoft = Company.where(title: 'Microsoft').first
microsoft.delete if microsoft

amazon = Company.where(title: 'Amazon').first
amazon.delete if amazon

companies = Company.create([title: 'Google', contact: '0178324658', email: 'employment@google.com'])
companies = Company.create([title: 'Microsoft', contact: '01643845612', email: 'jobs@microsoft.com'])
companies = Company.create([title: 'Amazon', contact: '0800612734', email: 'info@amazon.com'])

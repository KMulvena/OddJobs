class ApplicationMailer < ActionMailer::Base
  default to: "info@oddjobs.com", from: 'info@oddjobs.com'
  layout 'mailer'
end

class Job < ApplicationRecord
  belongs_to :company
  has_many :applications, dependent: :destroy
  validates :title, :company, :description, presence: true
  validates :salary, presence: true, numericality: true
end

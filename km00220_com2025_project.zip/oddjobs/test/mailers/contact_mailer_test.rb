require 'test_helper'

class ContactMailerTest < ActionMailer::TestCase
  test "should return contact email" do
    mail = ContactMailer.contact_email("km00220@surrey.ac.uk",
    "Kieran Mulvena", "1234567890", @message = "Hello")
    assert_equal ['info@oddjobs.com'], mail.to
    assert_equal ['info@oddjobs.com'], mail.from
  end
end

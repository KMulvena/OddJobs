require 'test_helper'

class JobTest < ActiveSupport::TestCase
  setup do
    @company = companies(:one)
  end

  test "dont save empty job" do
    job = Job.new

    job.save

    refute job.valid?
  end

  test "save non empty job" do
    job = Job.new
    job.title = "Software Engineer"
    job.description = "foo"
    job.company = @company
    job.salary = 100

    job.save
    assert job.valid?
  end
end

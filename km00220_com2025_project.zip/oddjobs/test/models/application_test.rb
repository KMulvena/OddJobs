require 'test_helper'

class ApplicationTest < ActiveSupport::TestCase
  setup do
    @job = jobs(:one)
  end
  test "dont save empty application" do
    application = Application.new

    application.save

    refute application.valid?
  end

  test "save non empty application" do
    application = Application.new
    application.job = @job
    application.name = "Gareth Jenkins"
    application.number = "123456789"
    application.email = "gj@gmail.com"
    application.application = "hello"

    application.save
    assert application.valid?
  end
end

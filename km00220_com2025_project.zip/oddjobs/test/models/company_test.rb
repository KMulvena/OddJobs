require 'test_helper'

class CompanyTest < ActiveSupport::TestCase
  test "dont save empty company" do
    company = Company.new
    company.save
    refute company.valid?
  end

  test "save valid company" do
    company = Company.new
    company.title = "Google"

    company.save
    assert company.valid?
  end

  test "avoid duplicate name" do
    company = Company.new
    company.title = "Google"
    company2 = Company.new
    company2.title = "Google"

    company.save
    assert company.valid?

    company2.save
    refute company2.valid?
  end
end
